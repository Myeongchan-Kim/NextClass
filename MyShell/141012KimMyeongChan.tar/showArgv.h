#ifndef H_STDIO
#define H_STDIO
	#include <stdio.h>
#endif

void showArgv(int, char*[]);
