# Myshell homework for OS class at 2015 2nd
Command : ls, ll, cp, rm, mv, cd, pwd, mkdir, rmdir

--------------------------------
ls : list of file of target directory
ls [dirname]

ex) ls 

print list of file of current directory

ex) ls /

print list of file of root directory

ex) ls ..

print list of file of parent directory

redirection : out '>'  

--------------------------------
ll : list of detail status of file of target directory


-------------------------------

cp : copy file

ex) cp file1 file2 
copy from file1 to file2

-------------- complete here  -----------------

pipe line : |

back ground execute : &
