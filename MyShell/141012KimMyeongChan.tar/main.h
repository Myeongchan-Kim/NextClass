#ifndef H_STDIO
#define H_STDIO
	#include <stdio.h>
#endif

#ifndef H_STDLIB
#define H_STDLIB
	#include <stdlib.h>
#endif

#ifndef CONST
#define CONST
	#include "const.h"
#endif


#include "showArgv.h"
#include "proc_cmd.h"
